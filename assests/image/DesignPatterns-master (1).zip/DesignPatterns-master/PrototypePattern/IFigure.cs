﻿using System;

namespace PrototypePattern
{
    interface IFigure : ICloneable
    {
        void GetInfo();
    }
}