﻿namespace SingletonPattern
{
    internal partial class ChocolateBoiler
    {
        private enum Status
        {
            Empty, InProgress, Boiled
        }
    }
}
