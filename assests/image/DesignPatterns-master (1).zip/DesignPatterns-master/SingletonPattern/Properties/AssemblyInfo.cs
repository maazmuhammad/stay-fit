﻿using System.Runtime.CompilerServices;

[assembly:InternalsVisibleTo("SingletonPattern.Tests")]
