﻿namespace ProxyPattern
{
    public interface Image
    {
        void display();

    }
}
