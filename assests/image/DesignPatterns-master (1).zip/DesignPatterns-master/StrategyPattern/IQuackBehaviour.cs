﻿namespace Ducks
{
    internal interface IQuackBehaviour
    {
        void Quack();
    }
}