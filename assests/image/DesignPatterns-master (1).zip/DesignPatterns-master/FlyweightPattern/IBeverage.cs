namespace FlyweightPattern
{
    public interface IBeverage
    {
        void Drink();
    }
}