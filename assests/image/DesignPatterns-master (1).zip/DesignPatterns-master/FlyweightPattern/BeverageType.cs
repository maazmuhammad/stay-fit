namespace FlyweightPattern
{
    public enum BeverageType
    {
        BubbleMilk, FoamMilk, OolongMilk, CoconutMilk
    }
}