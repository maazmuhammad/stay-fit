﻿namespace FactoryPattern
{
    internal class ThinCrust : IDough
    {
        public string Name => "Thin Crust";
    }
}