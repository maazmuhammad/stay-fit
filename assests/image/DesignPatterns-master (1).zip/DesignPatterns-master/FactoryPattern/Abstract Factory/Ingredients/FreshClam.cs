﻿namespace FactoryPattern
{
    internal class FreshClam : IClam
    {
        public string Name => "Fresh Clam";
    }
}