﻿namespace FactoryPattern
{
    internal class Onion : IVeggies
    {
        public Onion()
        {
        }

        public string Name => "Onions";
    }
}