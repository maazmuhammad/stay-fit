﻿namespace FactoryPattern
{
    internal class Pepper : IVeggies
    {

        public string Name => "Bell Peppers";
    }
}