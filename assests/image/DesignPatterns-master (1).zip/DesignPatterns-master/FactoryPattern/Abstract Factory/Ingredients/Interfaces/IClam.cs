﻿namespace FactoryPattern
{
    public interface IClam
    {
        string Name { get; }
    }
}