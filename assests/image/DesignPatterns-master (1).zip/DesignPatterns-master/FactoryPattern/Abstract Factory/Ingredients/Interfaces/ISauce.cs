﻿namespace FactoryPattern
{
    public interface ISauce
    {
        string Name { get; }
    }
}