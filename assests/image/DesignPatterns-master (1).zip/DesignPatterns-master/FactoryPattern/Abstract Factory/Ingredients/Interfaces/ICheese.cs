﻿namespace FactoryPattern
{
    public interface ICheese
    {
        string Name { get; }
    }
}