﻿namespace FactoryPattern
{
    public interface IVeggies
    {
        string Name { get; }
    }
}