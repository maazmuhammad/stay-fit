﻿namespace FactoryPattern
{
    internal class DeepDish : IDough
    {
        public string Name => "Deep Dish";
    }
}