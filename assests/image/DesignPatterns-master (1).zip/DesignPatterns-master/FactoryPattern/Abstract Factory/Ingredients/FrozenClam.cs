﻿namespace FactoryPattern
{
    internal class FrozenClam : IClam
    {
        public string Name => "Frozen Clam";
    }
}