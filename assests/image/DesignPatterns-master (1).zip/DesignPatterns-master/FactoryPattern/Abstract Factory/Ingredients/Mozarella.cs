﻿namespace FactoryPattern
{
    internal class Mozarella : ICheese
    {
        public string Name => "Mozarella";
    }
}